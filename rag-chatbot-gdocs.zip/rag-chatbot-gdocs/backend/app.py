from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from auth import google_login, google_callback
from gdocs import list_documents, fetch_document_content
from rag import query_rag

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def home():
    return {"message": "RAG Chatbot with Google Docs"}

@app.get("/login")
def login():
    return google_login()

@app.get("/callback")
def callback(code: str):
    return google_callback(code)

@app.get("/documents")
def get_documents(token: str):
    return list_documents(token)

@app.post("/chat")
def chat(query: str, selected_docs: list, token: str):
    docs_content = [fetch_document_content(doc_id, token) for doc_id in selected_docs]
    answer = query_rag(query, docs_content)
    return {"answer": answer}
