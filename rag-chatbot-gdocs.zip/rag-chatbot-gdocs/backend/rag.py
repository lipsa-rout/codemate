from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import openai

model = SentenceTransformer("all-MiniLM-L6-v2")

def embed_text(text):
    return model.encode([text])[0]

def build_index(docs):
    embeddings = [embed_text(doc) for doc in docs]
    dim = len(embeddings[0])
    index = faiss.IndexFlatL2(dim)
    index.add(np.array(embeddings))
    return index, docs

def query_rag(query, docs):
    index, docs = build_index(docs)
    q_emb = embed_text(query)
    D, I = index.search(np.array([q_emb]), k=1)
    best_doc = docs[I[0][0]]

    if D[0][0] > 1.2:
        return f"Not found in your documents. General Answer: {general_answer(query)}"
    
    return f"From your docs: {best_doc[:500]}..."

def general_answer(query):
    openai.api_key = "YOUR_API_KEY"
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": query}]
    )
    return response["choices"][0]["message"]["content"]
