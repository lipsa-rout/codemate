from googleapiclient.discovery import build

def list_documents(token):
    service = build("drive", "v3", credentials=token)
    results = service.files().list(
        q="mimeType='application/vnd.google-apps.document'",
        fields="files(id, name)"
    ).execute()
    return results.get("files", [])

def fetch_document_content(doc_id, token):
    service = build("docs", "v1", credentials=token)
    doc = service.documents().get(documentId=doc_id).execute()
    content = []
    for element in doc.get("body").get("content"):
        if "paragraph" in element:
            for elem in element["paragraph"]["elements"]:
                if "textRun" in elem:
                    content.append(elem["textRun"]["content"])
    return " ".join(content)
