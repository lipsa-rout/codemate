# RAG-powered Chatbot with Google Docs Integration

## Setup Instructions
1. Install dependencies:
   ```bash
   pip install -r backend/requirements.txt
   ```

2. Run the backend:
   ```bash
   uvicorn backend.app:app --reload
   ```

3. Open `frontend/index.html` in a browser.

## Features
- Google OAuth login
- Fetch and select Google Docs
- RAG pipeline with FAISS + Sentence Transformers
- Fallback to OpenAI if not found in docs
