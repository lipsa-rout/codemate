import os
from google_auth_oauthlib.flow import Flow

CLIENT_SECRETS_FILE = "credentials.json"
SCOPES = ["https://www.googleapis.com/auth/documents.readonly"]

def google_login():
    flow = Flow.from_client_secrets_file(
        CLIENT_SECRETS_FILE, scopes=SCOPES, redirect_uri="http://localhost:8000/callback"
    )
    auth_url, _ = flow.authorization_url(prompt="consent")
    return {"auth_url": auth_url}

def google_callback(code: str):
    flow = Flow.from_client_secrets_file(
        CLIENT_SECRETS_FILE, scopes=SCOPES, redirect_uri="http://localhost:8000/callback"
    )
    flow.fetch_token(code=code)
    credentials = flow.credentials
    return {"access_token": credentials.token}
