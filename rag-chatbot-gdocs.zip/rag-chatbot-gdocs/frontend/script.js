async function sendMessage() {
  let input = document.getElementById("userInput").value;
  let response = await fetch("http://localhost:8000/chat", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({query: input, selected_docs: ["docId1"], token: "USER_TOKEN"})
  });
  let data = await response.json();
  document.getElementById("chatbox").innerHTML += `<p>User: ${input}</p><p>Bot: ${data.answer}</p>`;
}
